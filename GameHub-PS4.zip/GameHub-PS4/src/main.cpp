#include <orbis/libkernel.h>
#include <orbis/Sysmodule.h>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>

struct LibraryItem {
    std::string id;
    std::string title;
    std::string category;
    std::string version;
    int size_mb;
    std::string url;
    std::string description;
};

static std::string read_file(const std::string& path) {
    std::ifstream file(path, std::ios::in | std::ios::binary);
    if (!file.is_open()) {
        return "";
    }
    std::ostringstream ss;
    ss << file.rdbuf();
    return ss.str();
}

static std::string extract_string_field(const std::string& block, const std::string& key) {
    std::string pattern = "\"" + key + "\"";
    size_t pos = block.find(pattern);
    if (pos == std::string::npos) return "";

    size_t colon = block.find(':', pos + pattern.size());
    if (colon == std::string::npos) return "";

    size_t first_quote = block.find('"', colon + 1);
    if (first_quote == std::string::npos) return "";

    size_t second_quote = block.find('"', first_quote + 1);
    if (second_quote == std::string::npos) return "";

    return block.substr(first_quote + 1, second_quote - first_quote - 1);
}

static int extract_int_field(const std::string& block, const std::string& key) {
    std::string pattern = "\"" + key + "\"";
    size_t pos = block.find(pattern);
    if (pos == std::string::npos) return 0;

    size_t colon = block.find(':', pos + pattern.size());
    if (colon == std::string::npos) return 0;

    size_t start = colon + 1;
    while (start < block.size() && (block[start] == ' ' || block[start] == '\t')) {
        ++start;
    }
    return std::atoi(block.c_str() + start);
}

static std::vector<LibraryItem> load_library(const std::string& json_path) {
    std::vector<LibraryItem> items;
    std::string content = read_file(json_path);
    if (content.empty()) {
        std::printf("[GameHub] Failed to read library file: %s\n", json_path.c_str());
        return items;
    }

    size_t pos = 0;
    while ((pos = content.find("\"id\"", pos)) != std::string::npos) {
        size_t obj_start = content.rfind('{', pos);
        size_t obj_end = content.find('}', pos);
        if (obj_start == std::string::npos || obj_end == std::string::npos || obj_end <= obj_start) {
            break;
        }

        std::string obj = content.substr(obj_start, obj_end - obj_start + 1);
        LibraryItem item;
        item.id = extract_string_field(obj, "id");
        item.title = extract_string_field(obj, "title");
        item.category = extract_string_field(obj, "category");
        item.version = extract_string_field(obj, "version");
        item.size_mb = extract_int_field(obj, "size_mb");
        item.url = extract_string_field(obj, "url");
        item.description = extract_string_field(obj, "description");

        if (!item.title.empty()) {
            items.push_back(item);
        }

        pos = obj_end + 1;
    }

    return items;
}

int main(int argc, char* argv[]) {
    (void)argc;
    (void)argv;

    std::printf("========================================\n");
    std::printf("        GameHub PS4 - Starting          \n");
    std::printf("========================================\n");

    std::vector<LibraryItem> items = load_library("/app0/assets/library.json");
    if (items.empty()) {
        items = load_library("data/library.json");
    }

    std::printf("[GameHub] Loaded items count: %zu\n", items.size());
    for (size_t i = 0; i < items.size(); ++i) {
        const auto& it = items[i];
        std::printf("[%zu] %s (%s) | v%s | %d MB\n",
                    i + 1, it.title.c_str(), it.category.c_str(),
                    it.version.c_str(), it.size_mb);
        std::printf("     URL: %s\n", it.url.c_str());
    }

    while (true) {
        sceKernelSleep(5);
    }

    return 0;
}

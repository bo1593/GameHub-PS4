#!/usr/bin/env bash
set -e

PROJECT_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$PROJECT_ROOT"

echo "[1/3] Compiling PS4 ELF..."
make

echo "[2/3] Preparing PKG staging directory..."
PKG_STAGE="$PROJECT_ROOT/build/pkg_stage"
rm -rf "$PKG_STAGE"
mkdir -p "$PKG_STAGE/sce_sys" "$PKG_STAGE/assets"

cp "$PROJECT_ROOT/build/GameHubPS4.elf" "$PKG_STAGE/eboot.bin"
cp "$PROJECT_ROOT/data/library.json" "$PKG_STAGE/assets/library.json"

[ -f "$PROJECT_ROOT/pkg_assets/icon0.png" ] && cp "$PROJECT_ROOT/pkg_assets/icon0.png" "$PKG_STAGE/sce_sys/icon0.png"
[ -f "$PROJECT_ROOT/pkg_assets/pic1.png" ] && cp "$PROJECT_ROOT/pkg_assets/pic1.png" "$PKG_STAGE/sce_sys/pic1.png"
[ -f "$PROJECT_ROOT/pkg_assets/param.sfo" ] && cp "$PROJECT_ROOT/pkg_assets/param.sfo" "$PKG_STAGE/sce_sys/param.sfo"

echo "[3/3] Staging complete at: $PKG_STAGE"
echo "Next: Use your PKG builder tool with $PKG_STAGE and param.sfo to generate GameHubPS4.pkg."

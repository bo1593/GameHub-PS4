# GameHub PS4

مشروع مبدئي لبناء تطبيق مكتبة ألعاب وتطبيقات لنظام PS4 المعدّل وجاهز للبناء عبر OpenOrbis Toolchain.

## محتويات المشروع
- `Makefile`: ملف البناء لتجميع الكود إلى ملف ELF.
- `build.sh`: سكربت لتشغيل البناء وتجهيز مجلد الترحيل `build/pkg_stage`.
- `data/library.json`: ملف بيانات الألعاب والتطبيقات والروابط (`url`).
- `src/main.cpp`: الكود الأساسي لقراءة المكتبة وعرض البيانات.
- `pkg_assets/icon0.png` و `pkg_assets/pic1.png`: صور مبدئية للأيقونة والخلفية (استبدلها بتصاميمك النهائية وأضف `param.sfo` الخاص بالحزمة).

## خطوات البناء
```bash
chmod +x build.sh
./build.sh
```
بعد تجهيز `build/pkg_stage` وإضافة `param.sfo`، استخدم أداة بناء حزم PKG المتوافقة مع بيئتك لإنتاج ملف `GameHubPS4.pkg`.
